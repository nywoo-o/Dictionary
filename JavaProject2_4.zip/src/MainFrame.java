import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Locale;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.inet.jortho.SpellChecker;
import com.inet.jortho.FileUserDictionary;
import com.inet.jortho.SpellCheckerOptions;
import com.inet.jortho.UserDictionaryProvider;
import com.inet.jortho.PopupListener;

public class MainFrame extends JFrame implements ActionListener, MouseListener {
	DB db;
	
	Container c;
	
	JPanel savedWordPanel;
	JPanel labelAndBtnPanel;
	JButton init;
	JTable words;
    JScrollPane scrollwords;
	DefaultTableModel modelwords;
	JLabel savedwords;
	
	//�ܾ� ���� start�ϴ� �г�
	JPanel startPanel;
	JRadioButton[] cnt = new JRadioButton[3], lang = new JRadioButton[2];
	JButton btnStartPrac, btnStartGame;
	ButtonGroup cntGrp, langGrp;
	
	//�ܾ� �߰��ϴ� �г�
	JPanel addWordPanel;
	JButton btnAddWord, btnDelWord;
	JLabel lblEng, lblKor;
	JTextField textEng, textKor;
	JPopupMenu popup;
	
	
	//���� ��ŸƮ ��ư
	JButton btnGameStart;
	
	String[] header = {"�ܾ�", "��", "�ϱ�Ƚ��"};
	String[] cntName = {"5��", "10��", "����"};

	public MainFrame(String title) {
		
		
		db = new DB();
		
		setTitle(title);
		setSize(700, 400);		
		setLocationRelativeTo(null); //���߾�		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		
        FontAndColor fc = new FontAndColor();		
		
        c = getContentPane();

		c.setLayout(new GridBagLayout());
		c.setBackground(fc.bgColor);
	
		GridBagConstraints gbconst = new GridBagConstraints();

		
		//�ܾ��Ʈ ǥ���ϴ� �κ�//
		savedWordPanel = new JPanel();
		savedWordPanel.setLayout(new BorderLayout());
		savedWordPanel.setBackground(fc.bgColor);
		
		modelwords = new DefaultTableModel(header, 0) {
			@Override
		    public boolean isCellEditable(int row, int column) {
		       //all cells false
		       return false;
		    }
		};
		
		
		words = new JTable(modelwords);
		words.setOpaque(true);
		words.setFillsViewportHeight(true);
		words.setBackground(Color.WHITE); //table�κ�
		words.getTableHeader().setBackground(fc.pointColor); //header�κ�
		words.getTableHeader().setFont(fc.pureGodic);
		words.setAutoCreateRowSorter(true); //��� �����ϸ� �ڵ� ����
		words.getTableHeader().setReorderingAllowed(false); //���ٲٱ� �Ұ�->����ġ�� ����/�ѱ� �Ǵ��ϹǷ�
		words.addMouseListener(this); //�ι�Ŭ���ϸ� �ܾ����
		words.getColumnModel().getColumn(2).setPreferredWidth(15); //�ܾ�Ƚ���κ� ũ�� ����
		words.setFont(fc.pureGodicThin);
		words.setToolTipText("����Ŭ���Ͻø� �ܾ �����˴ϴ�.");
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
		dtcr.setHorizontalAlignment(SwingConstants.RIGHT); //�ܾ�Ƚ�� �κ� ������ ����
		words.getColumnModel().getColumn(2).setCellRenderer(dtcr);
		
		db_selectAll(); //��񿡼� �޾ƿ�
		
		scrollwords = new JScrollPane(words,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollwords.setPreferredSize(new Dimension(340, 300));
		scrollwords.setBackground(fc.pointColor);
		scrollwords.getVerticalScrollBar().setBackground(fc.pointColor);
		labelAndBtnPanel = new JPanel();
		labelAndBtnPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
		savedwords = new JLabel("Number of words  : " + words.getRowCount()); //��
		savedwords.setBorder(BorderFactory.createEmptyBorder(0, 7, 0, 20));
		savedwords.setHorizontalAlignment(JLabel.CENTER);
		savedwords.setFont(fc.cambriaMath);
		
		init = new JButton("�ϱ�Ƚ�� �ʱ�ȭ");
		init.addActionListener(this);
		init.setFont(fc.pureGodic);
		init.setBackground(fc.pointColorPink);
		
		labelAndBtnPanel.add(savedwords);
		labelAndBtnPanel.add(init);
		labelAndBtnPanel.setBackground(fc.bgColor);
		
		savedWordPanel.add(labelAndBtnPanel, BorderLayout.NORTH);
		savedWordPanel.add(scrollwords);
		
		//�ܾ� �߰��ϴ� �κ�
		addWordPanel = new JPanel();
		addWordPanel.setLayout(new GridLayout(3, 2, 5, 5));
		addWordPanel.setBackground(fc.bgColor);
		
		lblEng = new JLabel("�ܾ�");
		lblKor = new JLabel("��");
		lblEng.setHorizontalAlignment(JLabel.CENTER);
		lblEng.setFont(fc.pureGodic);
		lblKor.setHorizontalAlignment(JLabel.CENTER);
		lblKor.setFont(fc.pureGodic);
		btnAddWord = new JButton("ADD");
		btnAddWord.addActionListener(this); //��ư Ŭ���ϸ� table�� �߰���
		btnAddWord.setFont(fc.consolas);
		btnAddWord.setBackground(fc.pointColorPink);
		btnDelWord = new JButton("Delete");
		btnDelWord.addActionListener(this); //������
		btnDelWord.setFont(fc.consolas);
		btnDelWord.setBackground(fc.pointColorPink);
		textEng = new JTextField();
		textEng.setFont(fc.pureGodic);
		//textEng.addMouseListener(new PopupListener(popup));
		textEng.addActionListener(this);
		//textEng.setToolTipText("������ Ŭ���� ���縵�� ���� �ܾ���õ");
		
		textKor = new JTextField();
		textKor.setFont(fc.pureGodic);
		textKor.addActionListener(this);
		
		settingSpellChecker();
		
		addWordPanel.add(lblEng);
		addWordPanel.add(textEng);
		addWordPanel.add(lblKor);
		addWordPanel.add(textKor);
		addWordPanel.add(btnDelWord);
		addWordPanel.add(btnAddWord);
		
		//�ܾ� ���� �����ϴ� �κ�
		startPanel = new JPanel();
		startPanel.setLayout(new GridLayout(2, 3, 5, 5)); //5, 5��  margin
		startPanel.setBackground(fc.bgColor);
		
		cntGrp = new ButtonGroup();
		for (int i = 0; i < cnt.length; ++i) {
			cnt[i] = new JRadioButton(cntName[i]);
			cntGrp.add(cnt[i]);
			startPanel.add(cnt[i]);
			cnt[i].setEnabled(false);
			cnt[i].setFont(fc.pureGodic);
			cnt[i].setBackground(fc.bgColor);
		}
		//ó�� ���۰�����ŭ Ȱ��ȭ
		int row = words.getRowCount();
		if (row >= 10) {
			cnt[1].setEnabled(true);
		}
		if (row >= 5) {
			cnt[0].setEnabled(true);
		}
		//ó�� ������ ���� ��ư����
		cnt[2].setEnabled(true);
		cnt[2].setSelected(true);
		
		
		langGrp = new ButtonGroup();
		lang[0] = new JRadioButton("�����");
		lang[1] = new JRadioButton("���縵����");
		lang[0].setFont(fc.pureGodic);
		lang[0].setSelected(true);
		lang[0].setBackground(fc.bgColor);
		lang[1].setFont(fc.pureGodic);
		lang[1].setBackground(fc.bgColor);
		langGrp.add(lang[0]);
		langGrp.add(lang[1]);
		
		startPanel.add(lang[0]);
		startPanel.add(lang[1]);
		
		btnStartPrac = new JButton("Start");
		btnStartPrac.addActionListener(this);
		btnStartPrac.setFont(fc.consolas);
		btnStartPrac.setBackground(fc.pointColorPink);
		startPanel.add(btnStartPrac);
		
		//game start button
		btnGameStart = new JButton("Game start!");
		btnGameStart.setFont(fc.consolas);
		btnGameStart.setBackground(fc.pointColorPink);
		btnGameStart.addActionListener(this);
		
		//contentPane�� �߰�
		gbconst.fill = GridBagConstraints.HORIZONTAL;
		gbconst.gridx = 0; gbconst.gridy = 0;
		gbconst.gridheight = 3; gbconst.gridwidth = 2;
		gbconst.insets = new Insets(0, 10, 0, 0);
		c.add(savedWordPanel, gbconst);
		
		gbconst.gridx = 2; gbconst.gridy = 0;
		gbconst.gridheight = 1; gbconst.gridheight = 1;
		gbconst.insets = new Insets(50, 10, 0, 10);
		gbconst.ipadx = 0;
		//gbconst.anchor = GridBagConstraints.PAGE_END;
		c.add(addWordPanel, gbconst);
		
		gbconst.gridx = 2; gbconst.gridy = 1;
		gbconst.gridheight = 1;
		gbconst.insets = new Insets(30, 10, 0, 10);
		c.add(startPanel, gbconst);
		
		gbconst.gridx = 2; gbconst.gridy = 2;
		gbconst.gridheight = 1;
		gbconst.insets = new Insets(0, 10, 20, 10);
		gbconst.anchor = GridBagConstraints.PAGE_END;
		c.add(btnGameStart, gbconst);
		setVisible(true);
	

		//englishâ�� Ŀ�� ��������
		textEng.requestFocus();
	}

	private void settingSpellChecker() {
		SpellChecker.setUserDictionaryProvider(new FileUserDictionary("/dictionary/"));
		SpellChecker.registerDictionaries(getClass().getResource("/dictionary/"), "en");
		SpellChecker.register(textEng);
		
		
	}

	private void db_selectAll() { //ó���� ��� DB�� �����ͼ� TABLE�� ������Ʈ
		db.sql = "SELECT * FROM WORDS";
		try {
			db.rs = db.stmt.executeQuery(db.sql);
			while(db.rs.next()) {
				String word = db.rs.getString("WORDS");
				String meaning = db.rs.getString("MEANING");
				String count = db.rs.getString("COUNT");
				System.out.println(word + meaning + count);
				String[] add = {word, meaning, count};
				modelwords.addRow(add);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		MainFrame mainFrame = new MainFrame("���ܾ� �н���_made by Nywoo");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource(); //������ ������Ʈ�� ����
		
		if (obj == btnAddWord) {
			addingWord(); 
		}
		else if (obj == btnDelWord) {
			deleteWord(); 
		}
		else if (obj == btnStartPrac) {
			startPractice();
		}
		else if (obj == btnGameStart) {
			if (words.getRowCount() == 0) return;
			this.setVisible(false);
			new GameFrame(this);
		}
		else if (obj == textEng) {
			//enter ġ�� textKor�� �����̵�
			textKor.requestFocus();
		} 
		else if (obj == textKor) {
			//enterġ�� �ѱ�
			addingWord();
			textEng.requestFocus();
		} 
		else if (obj == init) {
			for (int i = 0; i < words.getRowCount(); ++i) {
				db.update((String)words.getValueAt(i, 0), (String)words.getValueAt(i, 1), "0");
				words.setValueAt("0", i, 2);
			}
		}
	}

	private void startPractice() {
		
		int row = modelwords.getRowCount();
		if (row == 0) return;
		int howMany = row;
		if (cnt[0].isSelected()) {
			howMany = 5;
		}else if (cnt[1].isSelected()) {
			howMany = 10;
		}else if (cnt[2].isSelected()) {
			do {
			String tmp = JOptionPane.showInputDialog("������ ������ �Է��ϼ���");
			
			if (tmp == null || tmp.equals("")) return;
			for (int i = 0; i < tmp.length(); ++i) {
				if (Character.isDigit(tmp.charAt(i)) == false) {
					return;
				}
			}
			howMany = Integer.parseInt(tmp);
			} while (howMany > row || howMany <= 0);
		}

		
		int choice = 0;
		if (lang[1].isSelected()) {
			choice = 1;
		}
		this.setVisible(false);
		new WordPrac(howMany, choice, this);
	}

	private void deleteWord() {
		int rowToDel = words.getSelectedRow();
		if (rowToDel == -1) return;
		
		String[] delStr = new String[3];
		delStr[0] = (String)words.getValueAt(rowToDel, 0);
		delStr[1] = (String)words.getValueAt(rowToDel, 1);
		delStr[2] = (String)words.getValueAt(rowToDel, 2);
		
		rowToDel = words.convertRowIndexToModel(rowToDel);
		
		db.delete(delStr[0], delStr[1]);
		modelwords.removeRow(rowToDel);
		
		savedwords.setText("Number of words  : " + words.getRowCount());
		//�ܾ��� ������ n�� �̻��� �Ǹ� �� ��ư Ȱ��ȭ
		int row = modelwords.getRowCount();
		if (row < 5) {
			cnt[0].setEnabled(false);
		}
		else if (row < 10) {
			cnt[1].setEnabled(false);
		}
		
	}

	private void addingWord() {
		String[] inputStr = new String[3];
		inputStr[0] = textEng.getText();
		inputStr[1] = textKor.getText();
		inputStr[2] = "0";
		//��ĭ�̸� �߰� ����
		if (inputStr[0].equals("") || (inputStr[1].equals("")) 
				|| (db.exist(inputStr[0], inputStr[1]) == 1)){
			textEng.setText(""); 
			textKor.setText("");
			return;
		}
		
		modelwords.addRow(inputStr); //table�� �߰��ϰ�
		db.insert(inputStr[0], inputStr[1], inputStr[2]);
		textEng.setText(""); 
		textKor.setText("");
		savedwords.setText("Number of words  : " + words.getRowCount());
		//�ܾ��� ������ n�� �̻��� �Ǹ� �� ��ư Ȱ��ȭ
		int row = modelwords.getRowCount();
		
		if (row >= 10) {
			cnt[1].setEnabled(true);
		}
		else if (row >= 5) {
			cnt[0].setEnabled(true);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) { //����Ŭ���ϸ� �ܾ����
		Object obj = e.getSource();
		if (obj == words) {
			if (e.getClickCount() == 2) {
				deleteWord();
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}

