/*
 * 
*/
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Arrays;
import java.util.Random;

import javax.swing.*;

public class GameFrame extends JFrame implements WindowListener, ActionListener, MouseListener {
	MainFrame mainFrame;
	Container c;

	JPanel gameMonitor;
	JPanel gameTimer;
	JLabel explain;
	JLabel display;
	JButton stop, play;
	Timer timer;
	int count;

	
	JPanel btnPanel;
	JButton[] btn = new JButton[16];
	int cnt, correct, status; //status 0�̸� �ϳ� ����� 1�̸� �ΰ� �����->�Ǵ�
	int choice1 = -1, choice2;
	boolean[] chk; //�ߺ� üũ
	int[] selected;//i���� ��ư�� ���� �ܾ�����

	JPanel allCorrect;
	JLabel congr;
	
	JPanel timeOver;
	JLabel fail;
	
	FontAndColor fc = new FontAndColor();
	

	public GameFrame(MainFrame mainFrame) {
		this.mainFrame = mainFrame;

		setTitle("Word Game");
		setExtendedState(JFrame.MAXIMIZED_BOTH); 	
		setLocationRelativeTo(null); //���߾�		

		addWindowListener(this);

		c = getContentPane();
		c.setBackground(fc.bgColor);
		
		//�������� min(8, rowcount)�� ���
		//16���� �׸��� �� �� �������� ��� �� �ѹ� �ܾ� �ѹ� �Ѹ� 
		//�ܾ� �Ǵ� ���� Ŭ���ϰ� �����ؼ� (2��°��) �´� ��ư�� Ŭ���ϸ� �� ��ư�� �Ⱥ��̰� ��
		//�� Ǯ�� c���ٰ� borderlayout���� panel�� �¾ҽ��ϴ� �̹����� ����
		//�� �������� panel - ��ư �����ϴ� �κ� borderlayout ( jlabel, panel <gridlayout, 4*4 ��ư ����>)


		gameMonitor = new JPanel();
		gameMonitor.setLayout(new BorderLayout());
		gameMonitor.setBackground(fc.bgColor);
		btnPanel = new JPanel();
		btnPanel.setLayout(new GridLayout(4, 4, 15, 15));
		btnPanel.setBackground(fc.bgColor);
		cnt = Math.min(8, mainFrame.words.getRowCount());

		explain = new JLabel("�ܾ�� ���� ��Ī�ϼ���!   ");
		explain.setHorizontalAlignment(JLabel.CENTER);
		explain.setBorder(BorderFactory.createEmptyBorder(5, 0, 15, 0));
		explain.setFont(fc.pureGodicBig30);
		
		gameTimer = new JPanel();
		gameTimer.setBackground(fc.bgColor);
		
		count = 2*cnt;
		display = new JLabel(Integer.toString(count));
		display.setFont(fc.pureGodicBig30);
		display.setBorder(BorderFactory.createEmptyBorder(5, 10, 15, 10));
		ImageIcon stopImg = new ImageIcon(this.getClass().getResource("stop.png"));
		stop = new JButton(stopImg);
		stop.addActionListener(this);
		stop.setBackground(fc.pointColor);
		ImageIcon playImg = new ImageIcon(this.getClass().getResource("play-button.png"));
		play = new JButton(playImg);
		play.addActionListener(this);
		play.setBackground(fc.pointColor);
		
		timer = new Timer(1000, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				count--;
				if (count < 0) {
					timer.stop();
					gameMonitor.setVisible(false);
					c.add(timeOver);
				}else {
					display.setText(Integer.toString(count));
				}
			}
		});
		timer.setInitialDelay(1000);
		timer.start();
		gameTimer.add(explain);
		gameTimer.add(display);
		gameTimer.add(play);
		gameTimer.add(stop);
		
		
		for (int i = 0; i < 16; ++i) {
			btn[i] = new JButton();
			btn[i].setVisible(false);
			btnPanel.add(btn[i]);
			btn[i].setBackground(Color.LIGHT_GRAY);
			btn[i].addActionListener(this);
			btn[i].addMouseListener(this);
			btn[i].setFont(fc.pureGodicBig);
		}

		chk = new boolean[mainFrame.words.getRowCount()];
		selected = new int[16];
		Arrays.fill(selected, -1);

		//System.out.println(cnt);

		Random rnd=new Random();
		for (int i = 0; i < cnt; ++i) {

			//��ġ ������
			int wordpos = rnd.nextInt(16), meanpos = rnd.nextInt(16);
			while(selected[wordpos] != -1) {
				wordpos = rnd.nextInt(16);
			} selected[wordpos] = 0;
			while(selected[meanpos] != -1) {
				meanpos = rnd.nextInt(16);
			} selected[meanpos] = 0;


			//�ܾ� ������
			int what = rnd.nextInt(mainFrame.words.getRowCount());
			while(chk[what] == true) {
				what = rnd.nextInt(mainFrame.words.getRowCount());
			}
			chk[what] = true;

			btn[wordpos].setText((String)mainFrame.words.getValueAt(what, 0));
			btn[meanpos].setText((String)mainFrame.words.getValueAt(what, 1));
			btn[wordpos].setVisible(true);
			btn[meanpos].setVisible(true);
			
			selected[wordpos] = what;
			selected[meanpos] = what;
		}

		
		gameMonitor.add(gameTimer, BorderLayout.NORTH);
		gameMonitor.add(btnPanel);
		
		allCorrect = new JPanel();
		allCorrect.setLayout(new BorderLayout());
		allCorrect.setBackground(fc.bgColor);
		ImageIcon congraturation = new ImageIcon(this.getClass().getResource("congraturation.gif"));
		congr = new JLabel(congraturation);
		allCorrect.add(congr);
		
		timeOver = new JPanel();
		timeOver.setLayout(new BorderLayout());
		timeOver.setBackground(fc.bgColor);
		ImageIcon failIcon = new ImageIcon(this.getClass().getResource("gameover.png"));
		fail = new JLabel(failIcon);
		timeOver.add(fail);
		
		c.add(gameMonitor);
		//c.add(allCorrect);
		setVisible(true);

	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		mainFrame.setVisible(true); //������ �ٽ� mainframe���̰�
		this.dispose();

	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		 if (obj == stop) {
			timer.stop();
			display.setForeground(fc.pointColorPink);
			explain.setText("�����Ǿ����ϴ�!   ");
			btnPanel.setVisible(false);
		}else if (obj == play) {
			timer.start();
			display.setForeground(Color.BLACK);
			explain.setText("�ܾ�� ���� ��Ī�ϼ���!   ");
			btnPanel.setVisible(true);
		}
		else if (status == 0) {
			for (int i = 0; i < 16; ++i) {
				if (obj == btn[i]) {
					btn[i].setBackground(fc.pointColorPink);
					choice1 = i; break;
				}
			}
			status = 1;
		}
		else {
			for (int i = 0; i < 16; ++i) {
				if (obj == btn[i]) {
					choice2 = i; break;
				}
			}

			//�ܾ��� ¦�� ������ visible false
			if (selected[choice1] == selected[choice2] && choice1 != choice2) {
				btn[choice1].setVisible(false);
				btn[choice2].setVisible(false);
				correct++;
				
				if (correct == cnt) {//�� Ǯ��
					gameMonitor.setVisible(false);
					c.add(allCorrect);
					timer.stop();
				}
			}//�ȸ����� �״��
			else {
				btn[choice1].setBackground(Color.LIGHT_GRAY);
				choice1 = -1;
			}
			status = 0;
		}

		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		Object obj = e.getSource();
		
		for (int i = 0; i < 16; ++i) {
			if (obj == btn[i]) {
				if (i == choice1) break;
				btn[i].setBackground(fc.pointColor);
				break;
			}
		}		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		Object obj = e.getSource();
		for (int i = 0; i < 16; ++i) {
			if (obj == btn[i]) {
				if (i == choice1) break;
				btn[i].setBackground(Color.LIGHT_GRAY);
				break;
			}
		}	
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}


}

