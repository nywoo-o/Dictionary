import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
	public static final String URL ="jdbc:oracle:thin:@127.0.0.1:1521:XE"; 
	public static final String USER = "project";
	public static final String PASSWORD = "0524";
	public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	
	Connection conn; 
	Statement stmt;
	String sql = null;
	ResultSet rs;
	
	public DB() {
		try {
			Class.forName(DRIVER); // ����̹�
			conn = DriverManager.getConnection(
					URL ,USER, PASSWORD); //����̹� ����
			stmt = conn.createStatement();//���常���

			System.out.println("���� ����..!");
		} catch (ClassNotFoundException e) {
			System.out.println("����̹� �ε� ����...");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("DB ���� ����...");
			e.printStackTrace();

		}
	}
	
	public int insert(String word, String meaning, String cnt) {
		sql = "INSERT INTO WORDS VALUES ('"+ word +"', '"+ meaning + "', '" + cnt+"')";
		try {//1 :���� , 0 : ����
			return stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public void delete(String word, String meaning) {
		sql = "DELETE FROM WORDS WHERE WORDS = '" + word + "' AND MEANING = '"+ meaning + "'";
		try {//1 :���� , 0 : ����
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void update(String word, String meaning, String count) {
		sql = "UPDATE WORDS SET COUNT ='" + count + 
				"' WHERE WORDS = '" + word + "' AND MEANING = '" + meaning + "'";
		try {//1 :���� , 0 : ����
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int exist(String word, String meaning) {
		sql = "SELECT *  FROM WORDS WHERE WORDS = '" +word + "' AND MEANING = '" + meaning + "'";
		
		try {//1 :���� , 0 : ����
			return stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
}
