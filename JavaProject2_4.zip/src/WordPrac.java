
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Random;

import javax.swing.*;

import javafx.scene.layout.Border;

public class WordPrac extends JFrame implements WindowListener, ActionListener, KeyListener {
	Container cPrac;
	JPanel wordPanel, answerPanel;
	JLabel word, correctAns;

	JTextField answer;
	JButton submit;

	String[] pracWords;
	int howMany, choice, cur = 0, correct = 0;
	boolean[] chk;
	int[] selected;

	MainFrame mainFrame;

	public WordPrac(int howMany, int choice, MainFrame mainFrame) {
		this.howMany = howMany;
		this.choice = choice;
		this.mainFrame = mainFrame;

		setTitle(howMany+ "�� ��������");
		setSize(300, 300);		
		setLocationRelativeTo(null); //���߾�		

		addWindowListener(this);

		//�����ϰ� howMany���� ��� ȭ�鿡 ����Ұ���
		chk = new boolean[mainFrame.words.getRowCount()];
		selected = new int[howMany+1];

		Random rnd=new Random();
		for (int i = 0; i < howMany; ++i) {
			selected[i] = rnd.nextInt(mainFrame.words.getRowCount());
			while(chk[selected[i]]) {
				selected[i] = rnd.nextInt(mainFrame.words.getRowCount());
			}
			chk[selected[i]] = true;

		}
		//������ ��

		FontAndColor fc = new FontAndColor();
		
		cPrac = getContentPane();
		cPrac.setBackground(fc.bgColor);
		cPrac.setLayout(new GridLayout(2, 1));
		cPrac.addKeyListener(this);
		
		wordPanel = new JPanel();
		wordPanel.setLayout(new BorderLayout());
		wordPanel.setBackground(fc.bgColor);
		word = new JLabel((String)mainFrame.words.getValueAt(selected[0], choice)); //����� ������� �����ͼ� ���
		word.setHorizontalAlignment(JLabel.CENTER);
		word.setFont(fc.pureGodicBig);
		correctAns = new JLabel("<html>" + (cur+1) + "/" + howMany + "<br>" +
				" ���� ���� :" + correct + "/" + howMany + "</html>");
		correctAns.setHorizontalAlignment(JLabel.CENTER);
		correctAns.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
		correctAns.setFont(fc.pureGodicThin);
		wordPanel.add(correctAns, BorderLayout.NORTH);
		wordPanel.add(word);


		answerPanel = new JPanel();
		answerPanel.setLayout(null);
		answerPanel.setBackground(fc.bgColor);
		answer = new JTextField();
		answer.setHorizontalAlignment(JTextField.CENTER);
		answer.setBounds(45, 0, 200, 30);
		answer.addActionListener(this);

		submit = new JButton("SUBMIT");
	    submit.setBackground(fc.pointColorPink);
		submit.addActionListener(this);
		submit.setBounds(90, 50, 100, 25);
		submit.setFont(fc.consolas);
		
		answerPanel.add(answer);
		answerPanel.add(submit);

		cPrac.add(wordPanel);
		cPrac.add(answerPanel);
		setVisible(true);
		answer.requestFocus();
	}

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		mainFrame.setVisible(true); //������ �ٽ� mainframe���̰�
		this.dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == submit) {
			if (submit.getText().equals("SUBMIT")) {
				submitAns(); //�����̶� ������ Ȯ���ϰ� �������� ����ϴ� ȭ������ ��ȯ
			}
			else if (submit.getText().equals("NEXT!")){
				goingNext(); //�� Ǯ�� ����ȭ�� �ƴϸ� ����ȭ������ ��ȯ
			}
			else {//��Ǯ� �����ư�̸�
				mainFrame.setVisible(true); //������ �ٽ� mainframe���̰�
				this.dispose();
			}
		}
		else if (obj == answer) { //���� â���� enterġ��
			submitAns();
		}
	}

	private void goingNext() {
		answer.setVisible(true);
		submit.setText("SUBMIT");
		cur++;

		if (cur == howMany) {
			answer.setVisible(false);
			word.setText("");
			if (correct == 0) {
				word.setIcon(new ImageIcon(this.getClass().getResource("thumbsdown.gif")));
			}else {
				word.setIcon(new ImageIcon(this.getClass().getResource("excellent.gif")));
			}

			submit.setText("EXIT");
			return;
		}
		correctAns.setText("<html>" + (cur+1) + "/" + howMany + "<br>" +
				" ���� ���� :" + correct + "/" + howMany + "</html>");
		word.setText((String)mainFrame.words.getValueAt(selected[cur], choice));
		answer.requestFocus();
	}

	private void submitAns() {
		String ans = answer.getText();
		String realans = (String)mainFrame.words.getValueAt(selected[cur], -choice+1);
		if (ans.equals(realans)) {
			correct++;
			word.setText("�¾ҽ��ϴ�!");
			int realrow = mainFrame.words.convertRowIndexToModel(selected[cur]);
			
			String up = Integer.toString(Integer.parseInt((String)mainFrame.words.getValueAt(selected[cur], 2))+1);
			//db update
			
			mainFrame.db.update((String)mainFrame.words.getValueAt(selected[cur], 0),
					(String)mainFrame.words.getValueAt(selected[cur], 1), up);
			//jtable update
			mainFrame.words.setValueAt(up, selected[cur], 2);
			System.out.println(selected[cur] + " "+ realrow + " " + realans + " " + up);
		}
		else {
			word.setText("<html>Ʋ�Ƚ��ϴ�<br>������ \""+ realans + "\"</html>");
		}
		correctAns.setText("<html>" + (cur+1) + "/" + howMany + "<br>" +
				" ���� ���� :" + correct + "/" + howMany + "</html>");
		answer.setText("");
		answer.setVisible(false);

		submit.setText("NEXT!");
		cPrac.requestFocus();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		Object obj = e.getSource();
		if (obj == cPrac) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				if (cur == howMany) {
					mainFrame.setVisible(true); //������ �ٽ� mainframe���̰�
					this.dispose();
					return;
				}
				goingNext();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}



}

