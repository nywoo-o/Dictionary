import java.awt.Color;
import java.awt.Font;

public class FontAndColor {
	
	Font cambriaMath = new Font("Cambria Math", Font.BOLD, 15);
	Font pureGodic = new Font("���� ����", Font.BOLD, 12);
	Font pureGodicThin = new Font("���� ����", Font.PLAIN, 12);
	Font pureGodicBig = new Font("���� ����", Font.BOLD, 15);
	Font pureGodicBig30 = new Font("���� ����", Font.BOLD, 30);
	Font hyHeadLine = new Font("HYHeadLine", Font.BOLD, 13);
	Font consolas = new Font("Consolas", Font.BOLD, 15);
	
	Color bgColor = new Color(234, 215, 201);
	Color pointColor = new Color(218, 190, 152);
	Color pointColorPink = new Color(215, 124, 125);
	
}
