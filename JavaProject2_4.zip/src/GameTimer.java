import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GameTimer extends JPanel implements ActionListener{
	JLabel display;
	JButton stop, play;
	Timer timer;
	int count;

	public GameTimer() {
		count = 60;

		display = new JLabel("60");

		ImageIcon stopImg = new ImageIcon(this.getClass().getResource("stop.png"));
		stop = new JButton(stopImg);
		stop.addActionListener(this);
		ImageIcon playImg = new ImageIcon(this.getClass().getResource("play-button.png"));
		play = new JButton(playImg);
		play.addActionListener(this);

		add(display);
		add(play);
		add(stop);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if (obj == timer) {
			count--;
			if (count < 0) {
				timer.stop();
			}else {
				display.setText(Integer.toString(count));
			}
		}else if (obj == stop) {
			timer.stop();
		}else if (obj == play) {
			timer.start();
		}

	}
}
